<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 offset-md-2">
        <?php if($posts->isEmpty()): ?>
                <div class="jumbotron ">
                    <h1 style="text-align:center">No posts yet...</h1>
                </div>
        <?php else: ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-info" style="border-color:black">
                <div class="panel-heading" height="40" style="height:40px;border-color:black">
                    <a href="<?php echo e(route('post.show',$item)); ?>"><font size=3><b><?php echo e(str_limit($item->title, 80, '...')); ?></b></font></a>
                    <?php if(Auth::id()==$item->user->id): ?>
                        <div class="pull-right">
                                <div class="row">
                                <div class="col-4"> 
                                <form action="<?php echo e(route('post.toedit', $item)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-sm btn-primary" style="position:relative;bottom:5px;border-color:black">Edit</button>
                                </form>
                                </div>
                                <div class="col-4">
                                <form action="<?php echo e(route('post.destroy', $item)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-sm btn-danger" style="position:relative;bottom:5px;border-color:black">Delete</button>
                                </form>
                            </div>
                            </div>
                        </div>
                    <?php elseif(Auth::id()!=$item->user->id): ?>
                        <div class="pull-right">
                            <div class="row">
                                <div class="col-4"> 
                                    <button type="submit" class="btn btn-sm btn-primary disabled tooltip" style="position:relative;bottom:5px;border-color:black">
                                            <span class="tooltiptext">Can't edit what's not yours!</span> Edit</button>
                                    </form>
                                </div>
                                <div class="col-4">
                                    <button type="submit" class="btn btn-sm btn-danger disabled tooltip" style="position:relative;bottom:5px;border-color:black">
                                            <span class="tooltiptext">Can't delete what's not yours!</span> Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
                <span style="border:1px solid black; padding:2px; background-color:#e0e2e4"> <strong> &nbsp;<?php echo e($item->categories->name); ?>&nbsp; </strong> </span>  
                <span style="border:1px solid black; padding:2px; background-color:#daebe8">&nbsp;by <font color="blue"> <?php echo e($item->user->name); ?> </font></span>
                <div class="panel-body" style="margin:-15px 0px">
                <p><?php echo e(str_limit($item->content, 115 , '...')); ?></p>
            </div>
                <div class="panel-footer" height="20" style="height:20px;border-color:black">
                <small style="position:relative;bottom:10px"><strong><?php echo e($item->created_at->format('l, d F Y [H:i:s]')); ?> (<?php echo e($item->created_at->diffForHumans()); ?>)</strong></small>
              </div>
              
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>