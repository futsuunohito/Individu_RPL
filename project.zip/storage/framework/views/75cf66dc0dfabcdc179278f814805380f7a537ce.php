<div class="footer navbar-fixed-bottom bg-primary" style="position:;bottom:0px">
        <div class="container">
          <div class="pull-right hidden-xs">
            <b>Laravel Version : 5.6.11</b><br>
            <b>PHP Version : 7.2.3</b>
          </div>
          <small>
          <strong class="bg-dark"> Disclaimer : </strong>
          <p>
                This is not an actual product, some functions may not work. <br>
                All because the purpose of this website is to learn laravel, applying it's features to make CRUD based application. <br>
          </p>
          <strong class="bg-dark">Bogor Agricultural University, 2018</strong>
        </small>
        </div>
    </footer>