<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                    <div class="panel panel-info" style="border-color:black">
                        <div class="panel-heading" style="border-color:black"><font size=5> NEW ENTRY </font></div>
                        <div class="panel-body">
                            <form class="" action="<?php echo e(route('post.store')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group has-feedback<?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                    <label for="">I want to talk about :</label>
                                    <input type="text" class="form-control" name="title" placeholder="The thing you want to talk about" value="<?php echo e(old('title')); ?>">
                                        <?php if($errors->has('title')): ?>
                                            <span style="color:red" class="help-block">
                                            <p><?php echo e($errors->first('title')); ?></p>
                                            </span>
                                        <?php endif; ?>
                                </div>
                        
                                    <div class="form-group">
                                        <label for="genre">Choose your topic :</label>
                                        <select name="categories_id" id="" class="form-control"  width="150" height="30" style="width: 150px;height: 30px" >
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($categories->id); ?>"> <?php echo e($categories->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                        
                                    <div class="form-group  has-feedback<?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
                                    <label for="Content">What do you think about this?</label>
                                    <textarea name="content" rows="10" class="form-control" placeholder="Go on, open your mind."><?php echo e(old('content')); ?></textarea>
                                    <?php if($errors->has('content')): ?>
                                        <span style="color:red" class="help-block">
                                            <p><?php echo e($errors->first('content')); ?></p>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-block" style="border-color:black;" value="POST" >
                                  </div>
                                </form>
                        </div>
                    </div>
            </div>
        </div>

       
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>