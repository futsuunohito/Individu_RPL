<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="panel panel-info" style="border-color:black">
                <div class="panel-body">
                        <font size=5><b><?php echo e($posts->title); ?></b></font><br>
                        <span style="border:1px solid black; padding:2px; background-color:#daebe8">&nbsp;by <font color="blue"> <?php echo e($posts->user->name); ?> </font></span>
                        <span style="border:1px solid black; padding:2px; background-color:#e0e2e4"> <strong> &nbsp; <?php echo e($posts->categories->name); ?>&nbsp;    </strong> </span> 
                        <span style="border:1px solid black; padding:2px; background-color:#e0e2e4"> <strong> &nbsp; <?php echo e($posts->created_at->format('l, d F Y [H:i:s]')); ?>&nbsp;    </strong> </span>
                        <hr class="half-rule" style="border-color:black;margin:7px 0px"/>
                         <p><?php echo e($posts->content); ?></p>
               
                </div>
            </div>
            <div class="panel panel-info" style="border-color:black">
                <div class="panel-body">
                    <form action="<?php echo e(route('post.comment.store',$posts)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>    
                                <textarea name="message" id="" cols="30" rows="3" class="form-control" placeholder="Add a comment..."></textarea>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary btn-sm" value="Comment" style="position:relative;top:7px">
                                    </div>
                    </form>
                    <?php $__currentLoopData = $posts->comments()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <hr class="half-rule" style="border-color:black;margin:7px 0px"/>
                        
                    <font color="blue"> <?php echo e($comment->user->name); ?> </font>|| <small><?php echo e($comment->created_at->diffForHumans()); ?> </small>
                    <p style="word-wrap: break-word"><?php echo e($comment->message); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>