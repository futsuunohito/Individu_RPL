<script>
    window.setTimeout(function() {
    $(".alert").fadeTo(200, 0).slideUp(200, function(){
        $(this).remove(); 
    });
}, 2000);
</script>
<?php if(session('success')): ?>
<div class="row">
<div class="col-12">
    <div class="alert alert-success alert-dismissible" role="alert">
            
        <b><?php echo e(session('success')); ?></b>
    </div>
</div>   
</div>    
<?php endif; ?>

<?php if(session('info')): ?>
<div class="row">
<div class="col-12">
    <div class="alert alert-info alert-dismissible" role="alert">
           <strong><?php echo e(session('info')); ?></strong>
            
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(session('danger')): ?>
<div class="row">
<div class="col-12">
        <div class="alert alert-danger alert-dismissible" role="alert">
                <strong><?php echo e(session('danger')); ?></strong>
                 
             </div>
    </div>
</div>
<?php endif; ?>