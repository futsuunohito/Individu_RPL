<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="panel panel-info" style="border-color:black">
                <div class="panel-heading" style="border-color:black"><font size=5> EDIT ENTRY </font></div>
                    <div class="panel-body">
                        <form class="" action="<?php echo e(route('post.update', $posts)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('patch')); ?>

                            <div class="form-group">
                                <label for="">Change the title?</label>
                                <input type="text" class="form-control" name="title" placeholder="Post Title" value="<?php echo e($posts->title); ?>">
                            </div>
                    
                            <div class="form-group">
                                <label for="">Change the topic?</label>
                                <select name="categories_id" id="genre" class="form-control"  width="150" height="30" style="width: 150px;height: 30px" >
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categories->id); ?>"><?php echo e($categories->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                    
                            <div class="form-group">
                            <label for="Content">Change your thoughts?</label>
                            <textarea name="content" rows="4" class="form-control" placeholder="Tell me something about this"><?php echo e($posts->content); ?></textarea>
                            </div>
                            <div class="form-group">
                            <input type="submit" class="btn btn-block btn-primary" style="border-color:black" value="Save" >
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>